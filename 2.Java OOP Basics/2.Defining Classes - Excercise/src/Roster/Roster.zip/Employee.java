package Roster;

public class Employee implements Comparable<Employee>{
    private String name;
    private double salary;
    private String position;
    private String deparment;
    private String email;
    private int age;

    public Employee(String name, double salary, String position, String deparment, String email, int age) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.deparment = deparment;
        this.email = email;
        this.age = age;
    }

    public Employee(String name, double salary, String position, String deparment) {
        this(name , salary ,position , deparment , "n/a" , -1);
    }

    public Employee(String name, double salary, String position, String deparment, String email) {
        this(name , salary , position , deparment , email , -1);
        this.email = email;
    }

    public Employee(String name, double salary, String position, String deparment, int age) {
        this(name , salary , position , deparment , "n/a" , age);
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return String.format("%s %.2f %s %s", this.name , this.salary , this.email , this.age);
    }

    @Override
    public int compareTo(Employee employee) {
        return Double.compare(employee.salary, this.salary);
    }
}
